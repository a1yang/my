# Resume

Resume of BulletTech: https://bullettech2021.github.io/Resume/home/
